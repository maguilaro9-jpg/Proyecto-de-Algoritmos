import tkinter as tk
from tkinter import ttk, messagebox

import database as db
import servicios as s


def iniciar():
    db.crear_inventario()

    ventana = tk.Tk()
    ventana.title("Sistema de Inventario | Proyecto Final Algoritmos")
    ventana.geometry("1060x720")

    tabs = ttk.Notebook(ventana)
    tabs.pack(fill="both", expand=True, padx=12, pady=12)


    def modulo_crud(titulo, etiquetas, listar, agregar,
                    editar, eliminar):

        frame = ttk.Frame(tabs, padding=14)
        tabs.add(frame, text=titulo)

        ttk.Label(
            frame,
            text="Gestion de " + titulo,
            font=("Segoe UI", 18, "bold")
        ).pack(anchor="w", pady=8)

        formulario = ttk.Frame(frame)
        formulario.pack(fill="x")

        entradas = {}

        for i, etiqueta in enumerate(etiquetas):
            ttk.Label(
                formulario, text=etiqueta
            ).grid(row=i, column=0, sticky="w", pady=4)

            entrada = ttk.Entry(formulario, width=55)
            entrada.grid(
                row=i, column=1,
                sticky="ew", padx=10, pady=4
            )

            entradas[etiqueta] = entrada

        formulario.columnconfigure(1, weight=1)

        columnas = ("ID", *etiquetas)

        tabla = ttk.Treeview(
            frame,
            columns=columnas,
            show="headings",
            height=12
        )

        for columna in columnas:
            tabla.heading(columna, text=columna)
            tabla.column(
                columna,
                width=85 if columna == "ID" else 220
            )

        tabla.pack(fill="both", expand=True, pady=10)

        def actualizar():
            tabla.delete(*tabla.get_children())

            for fila in listar():
                tabla.insert("", "end", values=fila)

        def limpiar():
            for entrada in entradas.values():
                entrada.delete(0, "end")

            tabla.selection_remove(tabla.selection())

        def seleccionar(evento=None):
            seleccion = tabla.selection()

            if seleccion:
                valores = tabla.item(
                    seleccion[0], "values"
                )[1:]

                for entrada, valor in zip(
                    entradas.values(), valores
                ):
                    entrada.delete(0, "end")
                    entrada.insert(0, str(valor))

        def elegido():
            seleccion = tabla.selection()

            if not seleccion:
                raise ValueError(
                    "Selecciona un registro de la tabla."
                )

            return int(
                tabla.item(seleccion[0], "values")[0]
            )

        def ejecutar(accion):
            try:
                datos = [
                    entrada.get()
                    for entrada in entradas.values()
                ]

                if accion == "Agregar":
                    agregar(*datos)

                elif accion == "Editar":
                    editar(elegido(), *datos)

                elif accion == "Eliminar":
                    identificador = elegido()

                    confirmar = messagebox.askyesno(
                        "Confirmación",
                        "¿Eliminar este registro?"
                    )

                    if not confirmar:
                        return

                    eliminar(identificador)

                actualizar()
                limpiar()

                messagebox.showinfo(
                    "Correcto",
                    "Cambio guardado en Inventario.xlsx."
                )

            except (ValueError, OSError, PermissionError) as error:
                messagebox.showerror(
                    "Error",
                    str(error) +
                    "\nCierra Excel si está abierto."
                )

        barra = ttk.Frame(frame)
        barra.pack(fill="x")

        for accion in ("Agregar", "Editar", "Eliminar"):
            ttk.Button(
                barra,
                text=accion,
                command=lambda a=accion: ejecutar(a)
            ).pack(side="left", padx=4)

        ttk.Button(
            barra, text="Limpiar", command=limpiar
        ).pack(side="left", padx=4)

        ttk.Button(
            barra,
            text="Actualizar lista",
            command=actualizar
        ).pack(side="left", padx=4)

        tabla.bind("<<TreeviewSelect>>", seleccionar)

        actualizar()
        return actualizar

    actualizar_productos = modulo_crud(
        "Productos",
        ("Nombre", "Precio", "Existencia"),
        db.listar_productos,
        db.agregar_producto,
        db.editar_producto,
        db.eliminar_producto
    )

    actualizar_clientes = modulo_crud(
        "Clientes",
        ("Nombre", "NIT", "Dirección"),
        db.listar_clientes,
        db.agregar_cliente,
        db.editar_cliente,
        db.eliminar_cliente
    )

    

    pedidos = ttk.Frame(tabs, padding=15)
    tabs.add(pedidos, text="Pedidos")

    ttk.Label(
        pedidos,
        text="Pedidos y ventas",
        font=("Segoe UI", 18, "bold")
    ).pack(anchor="w", pady=8)

    formulario_pedidos = ttk.Frame(pedidos)
    formulario_pedidos.pack(fill="x")

    ttk.Label(
        formulario_pedidos, text="Cliente"
    ).grid(row=0, column=0, sticky="w")

    combo_cliente = ttk.Combobox(
        formulario_pedidos, state="readonly", width=55
    )
    combo_cliente.grid(row=0, column=1, pady=5)

    ttk.Label(
        formulario_pedidos, text="Producto"
    ).grid(row=1, column=0, sticky="w")

    combo_producto = ttk.Combobox(
        formulario_pedidos, state="readonly", width=55
    )
    combo_producto.grid(row=1, column=1, pady=5)

    ttk.Label(
        formulario_pedidos, text="Cantidad"
    ).grid(row=2, column=0, sticky="w")

    cantidad = ttk.Entry(formulario_pedidos, width=25)
    cantidad.grid(row=2, column=1, sticky="w", pady=5)

    columnas = (
        "ID", "Cliente", "Producto", "Cantidad", "Total Q"
    )

    tabla_pedidos = ttk.Treeview(
        pedidos, columns=columnas,
        show="headings", height=13
    )

    for columna in columnas:
        tabla_pedidos.heading(columna, text=columna)
        tabla_pedidos.column(columna, width=140)

    tabla_pedidos.pack(
        fill="both", expand=True, pady=12
    )

    ids_clientes = []
    ids_productos = []

    def refrescar_pedidos():
        nonlocal ids_clientes, ids_productos

        clientes = db.listar_clientes()
        productos = db.listar_productos()

        ids_clientes = [fila[0] for fila in clientes]
        ids_productos = [fila[0] for fila in productos]

        combo_cliente["values"] = [
            f"{fila[0]} - {fila[1]}"
            for fila in clientes
        ]

        combo_producto["values"] = [
            f"{fila[0]} - {fila[1]} | "
            f"Q{fila[2]:.2f} | stock {fila[3]}"
            for fila in productos
        ]

        combo_cliente.set("")
        combo_producto.set("")

        tabla_pedidos.delete(
            *tabla_pedidos.get_children()
        )

        for fila in s.listar_pedidos():
            tabla_pedidos.insert(
                "", "end", values=fila
            )

        actualizar_productos()
        actualizar_clientes()

    def guardar_pedido():
        try:
            indice_cliente = combo_cliente.current()
            indice_producto = combo_producto.current()

            if indice_cliente < 0 or indice_producto < 0:
                raise ValueError(
                    "Selecciona un cliente y un producto."
                )

            s.agregar_pedido(
                ids_clientes[indice_cliente],
                ids_productos[indice_producto],
                cantidad.get()
            )

            cantidad.delete(0, "end")
            refrescar_pedidos()

            messagebox.showinfo(
                "Pedido",
                "Pedido registrado y existencia actualizada."
            )

        except (ValueError, OSError) as error:
            messagebox.showerror("Error", str(error))

    def borrar_pedido():
        seleccion = tabla_pedidos.selection()

        if not seleccion:
            messagebox.showwarning(
                "Atención", "Selecciona un pedido."
            )
            return

        confirmar = messagebox.askyesno(
            "Confirmar",
            "¿Eliminar el pedido?\n"
            "El stock NO se repone automáticamente."
        )

        if confirmar:
            identificador = int(
                tabla_pedidos.item(
                    seleccion[0], "values"
                )[0]
            )

            s.eliminar_pedido(identificador)
            refrescar_pedidos()

    barra_pedidos = ttk.Frame(pedidos)
    barra_pedidos.pack(fill="x")

    ttk.Button(
        barra_pedidos,
        text="Agregar pedido",
        command=guardar_pedido
    ).pack(side="left", padx=4)

    ttk.Button(
        barra_pedidos,
        text="Eliminar pedido",
        command=borrar_pedido
    ).pack(side="left", padx=4)

    ttk.Button(
        barra_pedidos,
        text="Listar / Actualizar",
        command=refrescar_pedidos
    ).pack(side="left", padx=4)

    

    reportes = ttk.Frame(tabs, padding=15)
    tabs.add(reportes, text="Informes")

    ttk.Label(
        reportes,
        text="Informes de ventas",
        font=("Segoe UI", 18, "bold")
    ).pack(anchor="w")

    salida = tk.Text(
        reportes, height=23,
        font=("Consolas", 11)
    )

    salida.pack(
        fill="both", expand=True, pady=12
    )

    def mostrar_informe(tipo):
        clientes, productos = s.informes()

        datos = (
            clientes if tipo == "cliente"
            else productos
        )

        salida.delete("1.0", "end")

        salida.insert(
            "end",
            "TOTAL DE VENTAS POR " +
            tipo.upper() + "\n\n"
        )

        for nombre, valor in sorted(datos.items()):
            salida.insert(
                "end",
                f"{nombre:35} Q{valor:,.2f}\n"
            )

        salida.insert(
            "end",
            f"\nTOTAL GENERAL: Q{sum(datos.values()):,.2f}"
        )

    ttk.Button(
        reportes,
        text="Ventas por cliente",
        command=lambda: mostrar_informe("cliente")
    ).pack(side="left", padx=4)

    ttk.Button(
        reportes,
        text="Ventas por producto",
        command=lambda: mostrar_informe("producto")
    ).pack(side="left", padx=4)

    

    correo = ttk.Frame(tabs, padding=15)
    tabs.add(correo, text="Cotización / Correos")

    ttk.Label(
        correo,
        text="Cotizaciones y correo",
        font=("Segoe UI", 18, "bold")
    ).pack(anchor="w", pady=8)

    

    formulario_correo = ttk.Frame(correo)
    formulario_correo.pack(
        fill="x", padx=8, pady=8
    )

    campos = {}

    etiquetas = [
        ("cliente", "Nombre del cliente"),
        ("destino", "Correo del cliente / coordinador"),
        ("remitente", "Correo remitente"),
        ("clave", "Contraseña de aplicación SMTP"),
        ("smtp", "Servidor SMTP"),
        ("puerto", "Puerto SSL")
    ]

    for i, (clave, etiqueta) in enumerate(etiquetas):
        ttk.Label(
            formulario_correo,
            text=etiqueta
        ).grid(
            row=i+1, column=0,
            sticky="w", pady=7
        )

        entrada = ttk.Entry(
            formulario_correo,
            width=55,
            show="*" if clave == "clave" else ""
        )

        entrada.grid(
            row=i+1, column=1,
            sticky="w", padx=8
        )

        campos[clave] = entrada

    campos["smtp"].insert(0, "smtp.gmail.com")
    campos["puerto"].insert(0, "465")

    ttk.Label(
        formulario_correo,
        text="Producto para cotizar"
    ).grid(
        row=7, column=0,
        sticky="w", pady=7
    )

    combo_cotizacion = ttk.Combobox(
        formulario_correo,
        state="readonly",
        width=52
    )

    combo_cotizacion.grid(
        row=7, column=1, sticky="w"
    )

    def refrescar_cotizacion():
        productos = db.listar_productos()

        combo_cotizacion["values"] = [
            f"{fila[0]} - {fila[1]} (Q{fila[2]:.2f})"
            for fila in productos
        ]

        return productos

    def crear_solo_doc():
        try:
            productos = db.listar_productos()
            indice = combo_cotizacion.current()

            if indice < 0:
                raise ValueError(
                    "Selecciona un producto."
                )

            ruta = s.crear_cotizacion(
                campos["cliente"].get(),
                productos[indice][1],
                productos[indice][2]
            )

            messagebox.showinfo(
                "Word",
                f"Archivo creado:\n{ruta}"
            )

        except Exception as error:
            messagebox.showerror(
                "Error", str(error)
            )

    def enviar_cotizacion():
        try:
            productos = db.listar_productos()
            indice = combo_cotizacion.current()

            if indice < 0:
                raise ValueError(
                    "Selecciona un producto para cotizar."
                )

            ruta = s.crear_cotizacion(
                campos["cliente"].get(),
                productos[indice][1],
                productos[indice][2]
            )

            s.enviar_correo(
                campos["destino"].get(),
                "Cotización de producto",
                "Adjuntamos la cotización solicitada.",
                ruta,
                campos["remitente"].get(),
                campos["clave"].get(),
                campos["smtp"].get(),
                campos["puerto"].get()
            )

            messagebox.showinfo(
                "Cotización",
                "Cotización creada y correo enviado."
            )

        except Exception as error:
            messagebox.showerror(
                "No se pudo enviar", str(error)
            )

    def respaldar_y_enviar():
        try:
            ruta = s.copia_seguridad()

            s.enviar_correo(
                campos["destino"].get(),
                "Copia de seguridad Inventario.xlsx",
                "Se adjunta copia completa del inventario.",
                ruta,
                campos["remitente"].get(),
                campos["clave"].get(),
                campos["smtp"].get(),
                campos["puerto"].get()
            )

            messagebox.showinfo(
                "Respaldo",
                "Copia creada y enviada al coordinador."
            )

        except Exception as error:
            messagebox.showerror(
                "No se pudo enviar", str(error)
            )

    ttk.Button(
        formulario_correo,
        text="Actualizar productos",
        command=refrescar_cotizacion
    ).grid(row=8, column=0, pady=12)

    ttk.Button(
        formulario_correo,
        text="Crear Word",
        command=crear_solo_doc
    ).grid(row=8, column=1, sticky="w")

    ttk.Button(
        formulario_correo,
        text="Enviar cotización por correo",
        command=enviar_cotizacion
    ).grid(
        row=9, column=1,
        sticky="w", pady=7
    )

    ttk.Button(
        formulario_correo,
        text="Crear y enviar respaldo al coordinador",
        command=respaldar_y_enviar
    ).grid(
        row=10, column=1,
        sticky="w", pady=7
    )

    ttk.Label(
        formulario_correo,
        text=(
            "Usa una contraseña de aplicación SMTP.\n"
            "No escribas tu contraseña normal."
        ),
        foreground="#555"
    ).grid(
        row=11, column=0,
        columnspan=2,
        sticky="w", pady=15
    )

   

    refrescar_pedidos()
    refrescar_cotizacion()

    def cambiar_pestana(evento=None):
        nombre = tabs.tab(
            tabs.select(), "text"
        )

        if nombre in ("Pedidos", "Cotización / Correos"):
            refrescar_pedidos()
            refrescar_cotizacion()

    tabs.bind(
        "<<NotebookTabChanged>>",
        cambiar_pestana
    )

    ventana.mainloop()


if __name__ == "__main__":
    iniciar()