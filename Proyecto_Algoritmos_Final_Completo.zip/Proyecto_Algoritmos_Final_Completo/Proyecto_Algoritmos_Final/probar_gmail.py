import smtplib
import ssl
import socket

SERVIDOR = "smtp.gmail.com"
PUERTO = 465

print("================================")
print("   DIAGNOSTICO SMTP DE GMAIL")
print("================================")

try:
    print("\n1. Probando conexion TCP...")

    conexion = socket.create_connection(
        (SERVIDOR, PUERTO),
        timeout=15
    )

    print("OK: Conexion TCP establecida.")
    conexion.close()

    print("\n2. Probando conexion SSL/TLS...")

    contexto = ssl.create_default_context()

    with smtplib.SMTP_SSL(
        SERVIDOR,
        PUERTO,
        context=contexto,
        timeout=20
    ) as servidor:

        print("OK: Conexion SSL/TLS establecida.")

        print("\n3. Probando respuesta SMTP...")

        codigo, mensaje = servidor.ehlo()

        print("Codigo:", codigo)
        print("Respuesta:", mensaje.decode(
            errors="replace"
        ))

        print("\nDIAGNOSTICO FINAL:")
        print("La conexion segura con Gmail funciona.")
        print("El siguiente paso es revisar el login.")

except Exception as error:
    print("\nERROR DETECTADO:")
    print("Tipo:", type(error).__name__)
    print("Detalle:", str(error))

    print("\nLa prueba no llego a completarse.")