from pathlib import Path
from openpyxl import Workbook, load_workbook

RUTA_EXCEL = Path(__file__).resolve().parent / "Inventario.xlsx"


def crear_inventario():
    if RUTA_EXCEL.exists():
        return

    libro = Workbook()

    productos = libro.active
    productos.title = "productos"
    productos.append(["ID", "Nombre", "Precio", "Existencia"])

    clientes = libro.create_sheet("clientes")
    clientes.append(["ID", "Nombre", "NIT", "Dirección"])

    pedidos = libro.create_sheet("pedidos")
    pedidos.append([
        "ID", "Nombre cliente", "Nombre producto",
        "Cantidad producto", "Valor pedido"
    ])

    libro.save(RUTA_EXCEL)
    libro.close()


def siguiente_id(hoja):
    ids = [
        fila[0]
        for fila in hoja.iter_rows(min_row=2, values_only=True)
        if isinstance(fila[0], int)
    ]
    return max(ids, default=0) + 1


# ---------- PRODUCTOS ----------

def listar_productos():
    libro = load_workbook(RUTA_EXCEL)
    hoja = libro["productos"]
    datos = [
        fila for fila in hoja.iter_rows(min_row=2, values_only=True)
        if fila[0] is not None
    ]
    libro.close()
    return datos


def validar_producto(nombre, precio, existencia):
    nombre = nombre.strip()

    if not nombre:
        raise ValueError("El nombre no puede estar vacío.")

    try:
        precio = float(precio)
        existencia = int(existencia)
    except (TypeError, ValueError):
        raise ValueError("Precio y existencia deben ser números válidos.")

    if not (0 < precio < float("inf")):
        raise ValueError("El precio debe ser positivo y finito.")

    if existencia < 0:
        raise ValueError("La existencia no puede ser negativa.")

    return nombre, precio, existencia


def agregar_producto(nombre, precio, existencia):
    nombre, precio, existencia = validar_producto(
        nombre, precio, existencia
    )

    libro = load_workbook(RUTA_EXCEL)
    hoja = libro["productos"]

    for fila in hoja.iter_rows(min_row=2, values_only=True):
        if fila[1] and str(fila[1]).casefold() == nombre.casefold():
            libro.close()
            raise ValueError("Ese producto ya existe.")

    identificador = siguiente_id(hoja)
    hoja.append([identificador, nombre, precio, existencia])

    libro.save(RUTA_EXCEL)
    libro.close()
    return identificador


def editar_producto(id_producto, nombre, precio, existencia):
    nombre, precio, existencia = validar_producto(
        nombre, precio, existencia
    )

    libro = load_workbook(RUTA_EXCEL)
    hoja = libro["productos"]

    for fila in hoja.iter_rows(min_row=2, values_only=True):
        if (
            fila[0] != id_producto
            and fila[1]
            and str(fila[1]).casefold() == nombre.casefold()
        ):
            libro.close()
            raise ValueError("Ya existe otro producto con ese nombre.")

    for fila in hoja.iter_rows(min_row=2):
        if fila[0].value == id_producto:
            fila[1].value = nombre
            fila[2].value = precio
            fila[3].value = existencia

            libro.save(RUTA_EXCEL)
            libro.close()
            return True

    libro.close()
    return False


def eliminar_producto(id_producto):
    libro = load_workbook(RUTA_EXCEL)
    hoja = libro["productos"]

    for indice in range(2, hoja.max_row + 1):
        if hoja.cell(indice, 1).value == id_producto:
            hoja.delete_rows(indice)
            libro.save(RUTA_EXCEL)
            libro.close()
            return True

    libro.close()
    return False


def crear_datos_ejemplo():
    if not listar_productos():
        agregar_producto("Teclado", 150, 20)
        agregar_producto("Mouse", 75, 15)


# ---------- CLIENTES ----------

def validar_cliente(nombre, nit, direccion):
    nombre = str(nombre).strip()
    nit = str(nit).strip()
    direccion = str(direccion).strip()

    if not nombre or not nit or not direccion:
        raise ValueError("Nombre, NIT y dirección son obligatorios.")

    return nombre, nit, direccion


def listar_clientes():
    libro = load_workbook(RUTA_EXCEL)
    hoja = libro["clientes"]

    datos = [
        fila for fila in hoja.iter_rows(min_row=2, values_only=True)
        if fila[0] is not None
    ]

    libro.close()
    return datos


def agregar_cliente(nombre, nit, direccion):
    nombre, nit, direccion = validar_cliente(
        nombre, nit, direccion
    )

    libro = load_workbook(RUTA_EXCEL)
    hoja = libro["clientes"]

    for fila in hoja.iter_rows(min_row=2, values_only=True):
        if fila[2] and str(fila[2]).casefold() == nit.casefold():
            libro.close()
            raise ValueError("Ya existe un cliente con ese NIT.")

    nuevo_id = siguiente_id(hoja)
    hoja.append([nuevo_id, nombre, nit, direccion])

    libro.save(RUTA_EXCEL)
    libro.close()
    return nuevo_id


def editar_cliente(id_cliente, nombre, nit, direccion):
    nombre, nit, direccion = validar_cliente(
        nombre, nit, direccion
    )

    libro = load_workbook(RUTA_EXCEL)
    hoja = libro["clientes"]

    for fila in hoja.iter_rows(min_row=2, values_only=True):
        if (
            fila[0] != id_cliente
            and fila[2]
            and str(fila[2]).casefold() == nit.casefold()
        ):
            libro.close()
            raise ValueError("Ese NIT pertenece a otro cliente.")

    for fila in hoja.iter_rows(min_row=2):
        if fila[0].value == id_cliente:
            fila[1].value = nombre
            fila[2].value = nit
            fila[3].value = direccion

            libro.save(RUTA_EXCEL)
            libro.close()
            return True

    libro.close()
    return False


def eliminar_cliente(id_cliente):
    libro = load_workbook(RUTA_EXCEL)
    hoja = libro["clientes"]

    for indice in range(2, hoja.max_row + 1):
        if hoja.cell(indice, 1).value == id_cliente:
            hoja.delete_rows(indice)
            libro.save(RUTA_EXCEL)
            libro.close()
            return True

    libro.close()
    return False


if __name__ == "__main__":
    crear_inventario()
    crear_datos_ejemplo()

    for producto in listar_productos():
        print(producto)