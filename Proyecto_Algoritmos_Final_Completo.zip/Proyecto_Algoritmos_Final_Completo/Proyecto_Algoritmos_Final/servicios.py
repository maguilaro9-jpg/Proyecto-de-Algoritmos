from pathlib import Path
from collections import defaultdict
from datetime import datetime
from email.message import EmailMessage
import smtplib
import ssl

from docx import Document
from openpyxl import load_workbook

import database as db


# ==========================================
# CONFIGURACIÓN GENERAL
# ==========================================

BASE = Path(__file__).resolve().parent


# ==========================================
# LECTURA DE HOJAS DE EXCEL
# ==========================================

def leer_hoja(nombre_hoja):
    db.crear_inventario()

    libro = load_workbook(db.RUTA_EXCEL)

    try:
        hoja = libro[nombre_hoja]

        return [
            tuple(fila)
            for fila in hoja.iter_rows(
                min_row=2,
                values_only=True
            )
            if fila[0] is not None
        ]

    finally:
        libro.close()


# ==========================================
# MÓDULO DE PEDIDOS
# ==========================================

def listar_pedidos():
    return leer_hoja("pedidos")


def agregar_pedido(id_cliente, id_producto, cantidad):

    try:
        cantidad = int(cantidad)

    except (TypeError, ValueError):
        raise ValueError(
            "La cantidad debe ser un número entero."
        )

    if cantidad <= 0:
        raise ValueError(
            "La cantidad debe ser mayor que cero."
        )

    libro = load_workbook(db.RUTA_EXCEL)

    try:
        clientes = {
            fila[0]: fila
            for fila in libro["clientes"].iter_rows(
                min_row=2,
                values_only=True
            )
            if fila[0] is not None
        }

        productos = {
            fila[0]: fila
            for fila in libro["productos"].iter_rows(
                min_row=2,
                values_only=True
            )
            if fila[0] is not None
        }

        if id_cliente not in clientes:
            raise ValueError(
                "El cliente seleccionado no existe."
            )

        if id_producto not in productos:
            raise ValueError(
                "El producto seleccionado no existe."
            )

        producto = productos[id_producto]

        if producto[3] < cantidad:
            raise ValueError(
                "No hay suficiente existencia "
                "para realizar el pedido."
            )

        # Descontar existencia del producto
        for fila in libro["productos"].iter_rows(
            min_row=2
        ):
            if fila[0].value == id_producto:
                fila[3].value -= cantidad
                break

        hoja_pedidos = libro["pedidos"]

        nuevo_id = db.siguiente_id(
            hoja_pedidos
        )

        total = round(
            float(producto[2]) * cantidad,
            2
        )

        hoja_pedidos.append([
            nuevo_id,
            clientes[id_cliente][1],
            producto[1],
            cantidad,
            total
        ])

        libro.save(db.RUTA_EXCEL)

        return nuevo_id

    finally:
        libro.close()


def eliminar_pedido(id_pedido):

    libro = load_workbook(db.RUTA_EXCEL)

    try:
        hoja = libro["pedidos"]

        for indice in range(
            2,
            hoja.max_row + 1
        ):

            if hoja.cell(
                indice, 1
            ).value == id_pedido:

                hoja.delete_rows(indice)

                libro.save(db.RUTA_EXCEL)

                return True

        return False

    finally:
        libro.close()


# ==========================================
# MÓDULO DE INFORMES
# ==========================================

def informes():

    ventas_clientes = defaultdict(float)
    ventas_productos = defaultdict(float)

    pedidos = listar_pedidos()

    for (
        _,
        cliente,
        producto,
        cantidad,
        total
    ) in pedidos:

        ventas_clientes[str(cliente)] += float(
            total
        )

        ventas_productos[str(producto)] += float(
            total
        )

    return (
        dict(ventas_clientes),
        dict(ventas_productos)
    )


# ==========================================
# GENERACIÓN DE COTIZACIONES EN WORD
# ==========================================

def crear_cotizacion(
    nombre_cliente,
    nombre_producto,
    precio,
    destino=None
):

    if (
        not nombre_cliente.strip()
        or not nombre_producto.strip()
    ):
        raise ValueError(
            "Debes ingresar el nombre del cliente "
            "y seleccionar un producto."
        )

    documento = Document()

    documento.add_heading(
        "COTIZACIÓN",
        0
    )

    documento.add_paragraph(
        f"Estimado {nombre_cliente}"
    )

    documento.add_paragraph(
        "El precio de nuestro producto "
        f"{nombre_producto}"
    )

    documento.add_paragraph(
        f"es Q{float(precio):,.2f}"
    )

    if destino:
        ruta = Path(destino)

    else:
        ruta = BASE / "cotización.docx"

    documento.save(ruta)

    return ruta


# ==========================================
# ENVÍO DE CORREOS CON GMAIL SMTP
# ==========================================

def enviar_correo(
    destinatario,
    asunto,
    mensaje,
    adjunto,
    usuario,
    clave_app,
    servidor="smtp.gmail.com",
    puerto=465
):

    # Validar destinatario
    destinatario = destinatario.strip()

    if (
        not destinatario
        or "@" not in destinatario
    ):
        raise ValueError(
            "Ingresa un correo destinatario válido."
        )

    # Limpiar datos de acceso
    usuario = usuario.strip()

    # Google puede mostrar la contraseña
    # de aplicación separada por espacios.
    # Se eliminan antes de autenticar.
    clave_app = "".join(
        clave_app.split()
    )

    servidor = servidor.strip()

    if not usuario:
        raise ValueError(
            "Ingresa tu correo de Gmail."
        )

    if not clave_app:
        raise ValueError(
            "Ingresa la contraseña de aplicación "
            "generada por Google."
        )

    # Verificar archivo adjunto
    ruta = Path(adjunto)

    if not ruta.is_file():
        raise FileNotFoundError(
            f"No se encontró el archivo: {ruta}"
        )

    # Crear mensaje
    correo = EmailMessage()

    correo["From"] = usuario
    correo["To"] = destinatario
    correo["Subject"] = asunto

    correo.set_content(mensaje)

    # Detectar tipo de archivo
    extension = ruta.suffix.lower()

    if extension == ".docx":

        tipo = (
            "application/vnd.openxmlformats-officedocument."
            "wordprocessingml.document"
        )

    elif extension == ".xlsx":

        tipo = (
            "application/vnd.openxmlformats-officedocument."
            "spreadsheetml.sheet"
        )

    else:

        tipo = "application/octet-stream"

    principal, subtipo = tipo.split("/", 1)

    # Adjuntar archivo
    correo.add_attachment(
        ruta.read_bytes(),
        maintype=principal,
        subtype=subtipo,
        filename=ruta.name
    )

    # Configuración SSL segura
    contexto = ssl.create_default_context()

    try:

        print("\n================================")
        print("INICIANDO ENVÍO DE CORREO")
        print("================================")

        print("Servidor:", servidor)
        print("Puerto:", puerto)

        # Conectar con Gmail
        with smtplib.SMTP_SSL(
            servidor,
            int(puerto),
            context=contexto,
            timeout=30
        ) as smtp:

            print(
                "Conexión SSL establecida correctamente."
            )

            # Identificarse ante el servidor
            smtp.ehlo()

            print(
                "Servidor SMTP respondió correctamente."
            )

            # Iniciar sesión
            print(
                "Autenticando cuenta de Gmail..."
            )

            smtp.login(
                usuario,
                clave_app
            )

            print(
                "Autenticación exitosa."
            )

            # Enviar mensaje
            print(
                "Enviando correo electrónico..."
            )

            smtp.send_message(correo)

            print(
                "Correo enviado correctamente."
            )

        print("================================\n")

        return True

    # Error de autenticación
    except smtplib.SMTPAuthenticationError as error:

        raise ValueError(
            "Gmail rechazó el inicio de sesión.\n\n"
            "Verifica lo siguiente:\n"
            "1. Que tu Gmail sea correcto.\n"
            "2. Que uses una contraseña de aplicación.\n"
            "3. Que la contraseña pertenezca "
            "a ese mismo Gmail.\n"
            "4. Que no estés usando tu contraseña "
            "normal de Google."
        ) from error

    # Error al enviar a destinatarios
    except smtplib.SMTPRecipientsRefused as error:

        raise ValueError(
            "Gmail rechazó el correo destinatario. "
            "Verifica que esté escrito correctamente."
        ) from error

    # Error al enviar el mensaje
    except smtplib.SMTPSenderRefused as error:

        raise ValueError(
            "Gmail rechazó la dirección "
            "del correo remitente."
        ) from error

    # Otros errores SMTP
    except smtplib.SMTPException as error:

        raise ValueError(
            "Ocurrió un error con el servidor SMTP.\n"
            f"Detalle: {error}"
        ) from error

    # Errores de conexión
    except (
        OSError,
        TimeoutError
    ) as error:

        raise ValueError(
            "Se perdió la conexión con Gmail.\n\n"
            f"Detalle: {error}"
        ) from error



def copia_seguridad(destino=None):

    db.crear_inventario()

    if destino:

        ruta = Path(destino)

    else:

        carpeta = BASE / "Respaldos"

        nombre_archivo = (
            "Inventario_"
            f"{datetime.now():%Y%m%d_%H%M%S}"
            ".xlsx"
        )

        ruta = carpeta / nombre_archivo

    ruta.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    # Copiar el contenido del Excel
    ruta.write_bytes(
        db.RUTA_EXCEL.read_bytes()
    )

    return ruta