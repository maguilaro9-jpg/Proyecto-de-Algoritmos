import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import database


class TestClientes(unittest.TestCase):

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.patcher = patch.object(
            database,
            "RUTA_EXCEL",
            Path(self.temp.name) / "Inventario.xlsx"
        )
        self.patcher.start()
        database.crear_inventario()

    def tearDown(self):
        self.patcher.stop()
        self.temp.cleanup()

    def test_agregar_y_listar(self):
        self.assertEqual(
            database.agregar_cliente(
                "Ana", "123-4", "Jalapa"
            ),
            1
        )
        self.assertEqual(
            database.listar_clientes(),
            [(1, "Ana", "123-4", "Jalapa")]
        )

    def test_editar(self):
        identificador = database.agregar_cliente(
            "Ana", "123-4", "Jalapa"
        )
        self.assertTrue(
            database.editar_cliente(
                identificador,
                "Ana López",
                "123-4",
                "Guatemala"
            )
        )
        self.assertEqual(
            database.listar_clientes()[0][1],
            "Ana López"
        )

    def test_eliminar(self):
        identificador = database.agregar_cliente(
            "Ana", "123-4", "Jalapa"
        )
        self.assertTrue(
            database.eliminar_cliente(identificador)
        )
        self.assertEqual(database.listar_clientes(), [])

    def test_nit_duplicado(self):
        database.agregar_cliente("Ana", "123-4", "Jalapa")

        with self.assertRaises(ValueError):
            database.agregar_cliente(
                "Luis", "123-4", "Guatemala"
            )

    def test_campos_vacios(self):
        with self.assertRaises(ValueError):
            database.agregar_cliente(
                "", "123-4", "Jalapa"
            )


if __name__ == "__main__":
    unittest.main()