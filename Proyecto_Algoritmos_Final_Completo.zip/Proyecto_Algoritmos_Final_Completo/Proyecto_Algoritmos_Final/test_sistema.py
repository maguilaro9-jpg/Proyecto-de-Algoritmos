import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import database as db
import servicios as s


class PruebasSistema(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

        self.ruta = Path(self.tmp.name) / "Inventario.xlsx"
        self.parche = patch.object(
            db, "RUTA_EXCEL", self.ruta
        )
        self.parche.start()
        self.addCleanup(self.parche.stop)

        db.crear_inventario()

        self.cliente = db.agregar_cliente(
            "Ana López", "123-4", "Jalapa"
        )
        self.producto = db.agregar_producto(
            "Monitor", 250, 5
        )

    def test_pedido_descuenta_existencia(self):
        s.agregar_pedido(self.cliente, self.producto, 2)
        self.assertEqual(db.listar_productos()[0][3], 3)
        self.assertEqual(s.listar_pedidos()[0][4], 500)

    def test_cantidad_insuficiente(self):
        with self.assertRaises(ValueError):
            s.agregar_pedido(
                self.cliente, self.producto, 6
            )
        self.assertEqual(db.listar_productos()[0][3], 5)

    def test_informes(self):
        s.agregar_pedido(self.cliente, self.producto, 2)

        clientes, productos = s.informes()

        self.assertEqual(clientes["Ana López"], 500)
        self.assertEqual(productos["Monitor"], 500)

    def test_eliminar_pedido(self):
        identificador = s.agregar_pedido(
            self.cliente, self.producto, 1
        )
        self.assertTrue(
            s.eliminar_pedido(identificador)
        )
        self.assertEqual(s.listar_pedidos(), [])

    def test_cotizacion_word(self):
        ruta = Path(self.tmp.name) / "cotización.docx"

        s.crear_cotizacion(
            "Ana López", "Monitor", 250, ruta
        )

        self.assertTrue(ruta.exists())

        from docx import Document

        texto = " ".join(
            p.text for p in Document(ruta).paragraphs
        )

        self.assertIn("Ana López", texto)
        self.assertIn("Monitor", texto)

    def test_respaldo(self):
        destino = Path(self.tmp.name) / "copia.xlsx"

        self.assertEqual(
            s.copia_seguridad(destino),
            destino
        )
        self.assertTrue(destino.exists())
        self.assertEqual(
            destino.read_bytes(),
            self.ruta.read_bytes()
        )


if __name__ == "__main__":
    unittest.main()