# Proyecto Final Algoritmos 2026
Sistema de inventario en Python con Tkinter y Excel.

## Requisitos
Python 3.10+ con Tkinter, pip y conexión a Internet solo para instalar dependencias y enviar correos.

## Instalación
```powershell
py -m pip install -r requirements.txt
py main.py
```

## Pruebas
```powershell
py -m unittest discover -v
```

## Funciones
- Productos: agregar, editar, eliminar, listar.
- Clientes: agregar, editar, eliminar, listar.
- Pedidos: agregar, eliminar, listar; descuentan existencia al crear.
- Informes: ventas por cliente y producto.
- Cotización: genera `cotización.docx` y puede enviarla por correo.
- Respaldo: crea una copia completa de `Inventario.xlsx` y puede enviarla al coordinador.

## Correo
En pestaña **Cotización / Correos**, ingresa remitente, contraseña de aplicación, servidor y puerto SMTP SSL, y destinatario. Para Gmail suele ser smtp.gmail.com:465; se necesita una contraseña de aplicación habilitada. No se guardan credenciales.

## Notas de operación
- Cierra `Inventario.xlsx` en Excel antes de guardar desde la aplicación.
- La hoja de pedidos guarda los nombres exigidos por el PDF; si se cambia después el nombre de un producto o cliente, los pedidos históricos mantienen el nombre original.
- Eliminar un pedido no devuelve automáticamente unidades al inventario. Si deseas anular una venta con reposición, se requiere un proceso adicional.
- No se incluyen contraseñas, cuentas personales ni direcciones reales. Debes realizar una prueba real de correo con tus propias credenciales.
- `Inventario.xlsx` incluye únicamente encabezados, para comenzar con datos reales desde la interfaz.
