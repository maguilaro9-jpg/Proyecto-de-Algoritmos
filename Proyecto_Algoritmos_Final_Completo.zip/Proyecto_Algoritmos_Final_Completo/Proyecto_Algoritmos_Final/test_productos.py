import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import database


class PruebasProductos(unittest.TestCase):

    def setUp(self):
        self.temporal = tempfile.TemporaryDirectory()
        self.ruta = Path(self.temporal.name) / "Inventario.xlsx"
        self.parche = patch.object(database, "RUTA_EXCEL", self.ruta)
        self.parche.start()
        database.crear_inventario()

    def tearDown(self):
        self.parche.stop()
        self.temporal.cleanup()

    def test_crea_tres_hojas(self):
        from openpyxl import load_workbook

        libro = load_workbook(self.ruta)
        self.assertEqual(
            libro.sheetnames,
            ["productos", "clientes", "pedidos"]
        )
        libro.close()

    def test_agregar_y_listar(self):
        identificador = database.agregar_producto(
            "Monitor", "950", "8"
        )
        self.assertEqual(
            database.listar_productos(),
            [(identificador, "Monitor", 950, 8)]
        )

    def test_editar(self):
        identificador = database.agregar_producto(
            "Monitor", 950, 8
        )
        self.assertTrue(
            database.editar_producto(
                identificador, "Monitor", 900, 7
            )
        )
        self.assertEqual(
            database.listar_productos()[0][2:],
            (900, 7)
        )

    def test_eliminar(self):
        identificador = database.agregar_producto(
            "Monitor", 950, 8
        )
        self.assertTrue(
            database.eliminar_producto(identificador)
        )
        self.assertEqual(database.listar_productos(), [])

    def test_validacion_y_duplicados(self):
        database.agregar_producto("Mouse", 75, 10)

        with self.assertRaises(ValueError):
            database.agregar_producto("mouse", 90, 4)

        with self.assertRaises(ValueError):
            database.agregar_producto("Teclado", -1, 4)

        with self.assertRaises(ValueError):
            database.agregar_producto("Teclado", 100, -2)

    def test_datos_ejemplo_solo_una_vez(self):
        database.crear_datos_ejemplo()
        database.crear_datos_ejemplo()
        self.assertEqual(len(database.listar_productos()), 2)


if __name__ == "__main__":
    unittest.main()